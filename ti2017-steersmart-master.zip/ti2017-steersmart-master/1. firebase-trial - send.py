import time
from firebase import firebase
lat=64
log=36
while True:
        my_url = 'https://sample-5cb99.firebaseio.com'
        fb = firebase.FirebaseApplication(my_url, None)
        result = fb.patch(my_url, {'lat': lat, 'long': log})
        lat=lat+1
        log=log+1
        time.sleep(.01)
