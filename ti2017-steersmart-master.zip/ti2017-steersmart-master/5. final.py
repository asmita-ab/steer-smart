import serial
import time
import Adafruit_BBIO.UART as UART
import Adafruit_BBIO.GPIO as GPIO
import time
btn="P8_12"
GPIO.setup(btn, GPIO.IN)

#connecting GPS on UART4
UART.setup("UART4")
gps = serial.Serial('/dev/ttyO4', 9600, timeout=3.0)

#connecting GSM on UART1
UART.setup("UART1")
gsm = serial.Serial('/dev/ttyO1', 9600, timeout=3.0)

try:
    gsm.write('AT\r\n')
    rcv = gsm.read(20)
    print"GSM Working: "+rcv
    while True:
        #initialising GPS
		my_url = 'https://sample-5cb99.firebaseio.com/'
        fb = firebase.FirebaseApplication(my_url, None)
        rcvdfile=gps.read(1200)
        pos1 = rcvdfile.find("$GPRMC")
        pos2 = rcvdfile.find("\n",pos1)
        loc = rcvdfile[pos1:pos2]
        data = loc.split(',')
        pos11 = rcvdfile.find("$GPGGA")
        pos22 = rcvdfile.find("\n",pos11)
        loc1 = rcvdfile[pos11:pos22]
        data1 = loc1.split(',')
        if data[2]=='V':
            print 'No location found'
        else:
            result = fb.patch(my_url, {'lat': data[3]+data[4], 'long': data[5]+data[6]})
			print "Latitude = "+data[3]+data[4]
            print "Longitude = "+data[5]+data[6] 
            if GPIO.input(btn)==1:                
                gsm.write('AT+CMGS="9999136526"\r\n')
                print gsm.read(10)
                time.sleep(0.5)
                gsm.flushInput()
                gsm.flushOutput()
                gsm.write('EMERGENCY: I am in Danger. Latitude: '+data[3]+data[4]+', Longitude: '+data[5]+data[6])  # Message
                time.sleep(0.5)
                gsm.write('\x1A\r\n')
                print gsm.read(50)
                gsm.flushInput()
                gsm.flushOutput()
                print "Message sent"
                port.write('ATD 9999136526;\r\n')
                time.sleep(1)
                port.write('ATH\r\n')
                port.flushInput()
                port.flushOutput()
except:
    gsm.close()
    gps.close()
