import time
from firebase import firebase
while True:
        my_url = 'https://sample-5cb99.firebaseio.com'
        fb = firebase.FirebaseApplication(my_url, None)
        result = fb.get('/lat', None)
        print result
        time.sleep(.01)
