#https://learn.adafruit.com/connecting-a-push-button-to-beaglebone-black?view=all
import Adafruit_BBIO.GPIO as GPIO
import time
led="P8_10"
btn="P8_12"
GPIO.setup(led, GPIO.OUT)
GPIO.setup(btn, GPIO.IN)
while True:
    #GPIO.output(led, GPIO.LOW)
    if GPIO.input(btn)==1:        
        print "hi"
        time.sleep(0.5)
