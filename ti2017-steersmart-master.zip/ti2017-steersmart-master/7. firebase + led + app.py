import time
from firebase import firebase
import Adafruit_BBIO.GPIO as GPIO
led = "P8_10"
GPIO.setup(led, GPIO.OUT)
while True:
        my_url = 'https://sample-5cb99.firebaseio.com'
        fb = firebase.FirebaseApplication(my_url, None)
        state = fb.get('/led', None)
        print state
        if(state == 1):
                GPIO.output(led, GPIO.HIGH)
        else:
                GPIO.output(led, GPIO.LOW)
        time.sleep(.01)
