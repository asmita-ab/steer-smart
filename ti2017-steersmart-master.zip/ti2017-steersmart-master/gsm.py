import serial
import time
import Adafruit_BBIO.UART as UART
UART.setup("UART4")
port = serial.Serial('/dev/ttyO4', 9600, timeout=3.0)
try:
    print"GSM SIM900\n"
    print"AT               to check operations"
    port.write('AT\r\n')
    rcv = port.read(20)
    print"GSM Working: "+rcv
    while True:
            rcv = port.read(20)
            keyin = raw_input("Want to call ? press y else n\n")
            if(keyin=='y'):
                keyin = raw_input("Dial Number: ")
                keyin2 = 'ATD '+keyin+';\r\n'
                print"Dialing : " + keyin
                port.write(keyin2)
                time.sleep(2)
                keyin = raw_input("Type ATH or ath to cut call\n")
                port.write(keyin+'\r\n')
                port.flushInput()
                port.flushOutput()
            else:
                if keyin=="n"or"N":
                    rcv= port.read(50)
                    print rcv
                    time.sleep(2)
            if 'RING' in rcv:
                keyin=raw_input( 'Someone calling\n type ATA to accept')
                port.write(keyin+'\r\n')
            if '+CMTI:' in rcv:
                print "New Message received"
            port.flushInput()
            port.flushOutput()
            time.sleep(2)
except:
    port.close()
