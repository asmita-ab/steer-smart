import time
from firebase import firebase
import serial
import Adafruit_BBIO.UART as UART

#connecting GPS on UART1
UART.setup("UART1")
gps = serial.Serial('/dev/ttyO1', 9600, timeout=3.0)

while True:

        #ininitialising firebase
        #change my_url with the url of ur project
        my_url = 'https://sample-5cb99.firebaseio.com/'
        fb = firebase.FirebaseApplication(my_url, None)

        #initialising GPS
        rcvdfile=gps.read(1200)
        pos1 = rcvdfile.find("$GPRMC")
        pos2 = rcvdfile.find("\n",pos1)
        loc = rcvdfile[pos1:pos2]
        data = loc.split(',')
        pos11 = rcvdfile.find("$GPGGA")
        pos22 = rcvdfile.find("\n",pos11)
        loc1 = rcvdfile[pos11:pos22]
        data1 = loc1.split(',')
        if data[2]=='V':
                print 'No location found'
        else:
                result = fb.patch(my_url, {'lat': data[3]+data[4], 'long': data[5]+data[6]})
                print "Latitude = "+data[3]+data[4]
                print "Longitude = "+data[5]+data[6]        
                time.sleep(.01)
