import serial
import time
import Adafruit_BBIO.UART as UART
UART.setup("UART4")
gsm = serial.Serial('/dev/ttyO4', 9600, timeout=3.0)
try:
    while True:
        keyin = raw_input("Want to send Hello as sms ? press y else n\n")
        if(keyin=='y'):                
            keyin = raw_input("Contact: ")
            gsm.write('AT+CMGS="'+keyin+'"\r\n')
            print gsm.read(10)
            time.sleep(2)
            gsm.flushInput()
            gsm.flushOutput()
            gsm.write('Hello')  # Message
            time.sleep(2)
            gsm.write('\x1A\r\n')
            print gsm.read(50)
            gsm.flushInput()
            gsm.flushOutput()
            print "Message sent"            
except:
    gsm.close()
