import sys
import urllib2
import time
i=40
while(i<45): 
        f = urllib2.urlopen("https://api.thingspeak.com/update?api_key=NMRT2QIZBEXGNLBR&field1=%s"% (i))
        print "done - ",i
        f.close()
        i=i+1
        time.sleep(15)



